﻿using System;
using System.Numerics;
using System.Linq;

public class DifferentBaseCalculator
{
    private const string Digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    
    private static BigInteger BaseToDecimal(string number, int @base)
    {
        if (@base < 2 || @base > 36)
        {
            throw new ArgumentOutOfRangeException(nameof(@base), "Система числення має бути від 2 до 36.");
        }

        number = number.ToUpper();
        BigInteger result = 0;
        BigInteger power = 1;

        for (int i = number.Length - 1; i >= 0; i--)
        {
            int digitValue = Digits.IndexOf(number[i]);

            
            if (digitValue == -1 || digitValue >= @base)
            {
                throw new FormatException($"Символ '{number[i]}' недійсний для системи числення основи {@base}.");
            }

            result += digitValue * power;
            power *= @base;
        }

        return result;
    }

    
    private static string DecimalToBase(BigInteger number, int @base)
    {
        if (@base < 2 || @base > 36)
        {
            throw new ArgumentOutOfRangeException(nameof(@base), "Система числення має бути від 2 до 36.");
        }
        if (number.Sign == 0) return "0";

        bool isNegative = number.Sign == -1;
        if (isNegative) number = BigInteger.Abs(number);

        string result = "";
        while (number > 0)
        {
            int remainder = (int)(number % @base);
            result = Digits[remainder] + result;
            number /= @base;
        }

        return isNegative ? "-" + result : result;
    }

    public static void RunCalculator()
    {
        Console.WriteLine("--- Калькулятор у різних системах числення ---");
        int @base;
        char operation;
        string num1Base, num2Base;

        
        while (true)
        {
            Console.Write("Введіть систему числення (2-36): ");
            if (int.TryParse(Console.ReadLine(), out @base) && @base >= 2 && @base <= 36) break;
            Console.WriteLine("Невірне введення. Спробуйте ще раз.");
        }

        
        while (true)
        {
            Console.Write("Введіть арифметичну дію (+, -, *, /): ");
            if (char.TryParse(Console.ReadLine(), out operation) && "+-*/".Contains(operation)) break;
            Console.WriteLine("Невірна операція. Спробуйте ще раз.");
        }

        
        while (true)
        {
            Console.Write($"Введіть перше число в системі числення (основа {@base}): ");
            num1Base = Console.ReadLine();
            try
            {
                BaseToDecimal(num1Base, @base); 
                break;
            }
            catch (Exception ex) when (ex is FormatException || ex is ArgumentOutOfRangeException)
            {
                Console.WriteLine($"Помилка валідації: {ex.Message}");
            }
        }

        
        while (true)
        {
            Console.Write($"Введіть друге число в системі числення (основа {@base}): ");
            num2Base = Console.ReadLine();
            try
            {
                BaseToDecimal(num2Base, @base); 
                break;
            }
            catch (Exception ex) when (ex is FormatException || ex is ArgumentOutOfRangeException)
            {
                Console.WriteLine($"Помилка валідації: {ex.Message}");
            }
        }

       
        try
        {
            BigInteger decimal1 = BaseToDecimal(num1Base, @base);
            BigInteger decimal2 = BaseToDecimal(num2Base, @base);
            BigInteger resultDecimal = 0;

            switch (operation)
            {
                case '+':
                    resultDecimal = decimal1 + decimal2;
                    break;
                case '-':
                    resultDecimal = decimal1 - decimal2;
                    break;
                case '*':
                    resultDecimal = decimal1 * decimal2;
                    break;
                case '/':
                    if (decimal2 == 0)
                    {
                        Console.WriteLine("Помилка: Ділення на нуль!");
                        return;
                    }
                    resultDecimal = decimal1 / decimal2; 
                    break;
            }

            string resultBase = DecimalToBase(resultDecimal, @base);

            Console.WriteLine($"\n--- РЕЗУЛЬТАТ ---\n({num1Base})_{@base} {operation} ({num2Base})_{@base} = ({resultBase})_{@base}");
            Console.WriteLine($"Перевірка в десятковій: {decimal1} {operation} {decimal2} = {resultDecimal}");
        }
        catch (Exception ex)
        {
            
            Console.WriteLine($"Виникла неочікувана помилка: {ex.Message}");
        }
    }

    public static void Main(string[] args)
    {
        DifferentBaseCalculator.RunCalculator();
    }


}